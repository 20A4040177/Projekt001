USE [EShop]
GO

/****** Object:  Trigger [dbo].[trg_dec_quantity]    Script Date: 6/2/2020 9:24:50 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE trigger [dbo].[trg_dec_quantity] on [dbo].[tblImInvoiceDetail] for update as
begin update tblItemList
set Quantity=tblItemList.Quantity-(select Quantity from deleted where ItemID=tblItemList.ItemID)+(select Quantity from inserted where ItemID=tblItemList.ItemID)
from tblItemList join inserted on tblItemList.ItemID=inserted.ItemID
end
GO

