USE [EShop]
GO

/****** Object:  Trigger [dbo].[trg_update_sale_price]    Script Date: 6/2/2020 9:26:33 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create trigger [dbo].[trg_update_sale_price] on [dbo].[tblItemList] after update as
begin
update tblItemList
set SaleUnitPrice=1.1*inserted.ImUnitPrice from inserted where tblItemList.ItemID=inserted.ItemID
end
select* from tblItemList
GO

