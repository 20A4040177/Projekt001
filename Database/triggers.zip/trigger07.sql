USE [EShop]
GO

/****** Object:  Trigger [dbo].[trg_dec_quantity_sale]    Script Date: 6/2/2020 9:26:49 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create trigger [dbo].[trg_dec_quantity_sale] on [dbo].[tblSaleInvoiceDetail] after insert as
begin update tblItemList
set Quantity=tblItemList.Quantity-(select Quantity from inserted where ItemID=tblItemList.ItemID)
from tblItemList join inserted on tblItemList.ItemID=inserted.ItemID
end

GO

