USE [EShop]
GO

/****** Object:  Trigger [dbo].[trg_update__update_im_price]    Script Date: 6/2/2020 9:25:53 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create trigger [dbo].[trg_update__update_im_price] on [dbo].[tblImInvoiceDetail] after update as
begin 
update tblItemList
set ImUnitPrice=UnitPrice from inserted where inserted.ItemID=tblItemList.ItemID
end
GO

