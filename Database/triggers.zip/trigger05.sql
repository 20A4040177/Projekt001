USE [EShop]
GO

/****** Object:  Trigger [dbo].[trg_update_im_price]    Script Date: 6/2/2020 9:26:04 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create trigger [dbo].[trg_update_im_price] on [dbo].[tblImInvoiceDetail] after insert as
begin
update tblItemList
set ImUnitPrice= UnitPrice from inserted where inserted.ItemID=tblItemList.ItemID

end
GO

