USE [EShop]
GO

/****** Object:  Trigger [dbo].[trg_del_quantity_sale]    Script Date: 6/2/2020 9:26:57 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE trigger [dbo].[trg_del_quantity_sale] on [dbo].[tblSaleInvoiceDetail] for delete as
begin update tblItemList
set Quantity=tblItemList.Quantity+(select Quantity from deleted where ItemID=tblItemList.ItemID)
from tblItemList join deleted on tblItemList.ItemID=deleted.ItemID
end
GO

