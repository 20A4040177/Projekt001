USE [EShop]
GO

/****** Object:  Trigger [dbo].[trg_del_quantity]    Script Date: 6/2/2020 9:25:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE trigger [dbo].[trg_del_quantity] on [dbo].[tblImInvoiceDetail] for delete as
begin update tblItemList
set Quantity=tblItemList.Quantity-(select Quantity from deleted where ItemID=tblItemList.ItemID)
from tblItemList join deleted on tblItemList.ItemID=deleted.ItemID
end
GO

