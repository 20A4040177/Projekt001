USE [EShop]
GO

/****** Object:  Trigger [dbo].[trg_inc_quantity]    Script Date: 6/2/2020 9:25:44 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE trigger [dbo].[trg_inc_quantity] on [dbo].[tblImInvoiceDetail] after insert as
begin 
update tblItemList 
set Quantity=tblItemList.Quantity+(select Quantity from inserted where ItemID=tblItemList.ItemID)
from tblItemList join inserted on tblItemList.ItemID=inserted.ItemID
end
GO

